module com.schemefinder {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.base;

    opens com.schemefinder to javafx.fxml;
    exports com.schemefinder;
}
